export const API_URLS = {
  mainpage: "http://private-12729-proyect1.apiary-mock.com/teams"
};
