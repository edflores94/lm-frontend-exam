import getMainApi from "api/main";
import { getMainRequest } from "requests/requests";

async function mainCallProccess() {
  let mainResponse = null;

  try {
    const mainRequest = getMainRequest();
    const mainCall = getMainApi(mainRequest);

    mainResponse = await mainCall;
    return mainResponse.data;
  } catch (error) {
    console.log(error);
  }
}

export default mainCallProccess;
