import React, { Fragment, useState, useEffect } from "react";
import mainCallProccess from "logic/mainCall";
import Header from "components/Header";
import Team from "components/Team";
import { getCodeErrors, isUsernameValid } from "utils/login/userValidation";
import { USER_INVALID_MSG } from "common/constants";

function Home(props) {
  const [renderFlag, setRenderFlag] = useState(false);
  const [isUserError, setIsUserError] = useState(false);
  const [userError, setUserError] = useState("");
  const [isPasswordError, setIsPasswordError] = useState(false);
  const [errorTexts, setErrorTexts] = useState([]);
  const [data, setData] = useState("");
  

  useEffect(async () => {
    const response = await mainCallProccess();
    const credentials = response.credenciales;
    const userValid = isUsernameValid(credentials.user);
    if (!userValid) {
      setIsUserError(true);
      setUserError(USER_INVALID_MSG);
    } else {
      const errors = getCodeErrors(credentials);
      if (errors.length > 0) {
        setIsPasswordError(true);
        setErrorTexts(errors);
      } else {
        setRenderFlag(true);
        setData(response);
      }
    }
  }, []);

  /** render functions */
  if (renderFlag) {
    return (
      <Fragment>
        <div>Success</div>
        <Header data={data}/>
        <Team data={data}/>
      </Fragment>
    );
  } else {
    return (
      <div>
        {isUserError && <div> {userError}</div>}
        {isPasswordError && errorTexts && errorTexts.map(item => <p>{item}</p>)}
      </div>
    );
  }
}

export default Home;
