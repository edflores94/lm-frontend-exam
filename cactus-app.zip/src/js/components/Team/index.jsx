import React from "react";
import { makeStyles } from "@material-ui/core";
import PlayerCard from "components/Card/PlayerCard";
import styles from "./Team.scss";

const useStyles = makeStyles(() => ({
  header: {
    backgroundColor: "#400CCC",
    flexDirection: "row",
    "@media (max-width: 900px)": {
      paddingLeft: 0
    }
  },
  menuButton: {
    fontFamily: "sans-serif",
    fontWeight: 300,
    size: "18px"
  },
  toolbar: {
    display: "flex",
    width: "100%",
    justifyContent: "flex-start"
  }
}));

export default function Team(props) {
  /* start desktop functions */
  function render() {
    debugger;
    const { data } = props;
    const body = data && data.body ? data.body : [];

    return (
      <div className={styles.teamDiv}>
        {body.map((element, key) => {
          //const players = element.players ? element.players : [];
          return key < 4 ? (
            <div className={styles.cardContent}>
              <PlayerCard />
            </div>
          ) : null;
        })}
      </div>
    );
  }

  if (props.data) {
    return render();
  } else {
    return null;
  }
}
