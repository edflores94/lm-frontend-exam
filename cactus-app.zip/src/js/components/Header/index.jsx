import React from "react";
import { Link as RouterLink } from "react-router-dom";
import { LazyLoadImage } from "react-lazy-load-image-component";
import { AppBar, Toolbar, makeStyles, Button } from "@material-ui/core";
import { publicPath } from "common/routeConfig";

import styles from "./Header.scss";

const useStyles = makeStyles(() => ({
  header: {
    backgroundColor: "#400CCC",
    flexDirection: "row",
    "@media (max-width: 900px)": {
      paddingLeft: 0
    }
  },
  menuButton: {
    fontFamily: "sans-serif",
    fontWeight: 300,
    size: "18px"
  },
  toolbar: {
    display: "flex",
    width: "100%",
    justifyContent: "flex-start"
  }
}));

export default function Header(props) {
  const reactAppLogo = (
    <LazyLoadImage
      effect="blur"
      src={"https://d296xu67oj0g2g.cloudfront.net/website_assets/public/images/lifemiles-logo-white.svg"}
      alt={"description"}
      key={"logo"}
      height="70px"
      width="80px"
    />
  );

  /* start desktop functions */
  function renderContent() {
    debugger;
    const { data } = props;
    const credentials = data && data.credenciales ? data.credenciales : [];
    const userName = credentials.user ? credentials.user : "";
    const { menuButton, toolbar } = useStyles();
    return (
      <Toolbar className={toolbar}>
        <div className={styles.menuDiv}>
          <div className={styles.userSection}>{userName}</div>
          <div className={styles.logoSection}>
            <Button
              {...{
                color: "inherit",
                to: publicPath,
                component: RouterLink,
                className: menuButton
              }}
            >
              {reactAppLogo}
            </Button>
          </div>
        </div>
      </Toolbar>
    );
  }

  /* end desktop functions */

  const { header } = useStyles();
  return (
    <AppBar position="fixed" className={header} style={{ backgroundColor: "#008080" }}>
      {renderContent()}
    </AppBar>
  );
}
