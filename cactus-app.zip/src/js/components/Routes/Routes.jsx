import React from "react";
import { Route, Switch } from "react-router-dom";
import Home from "views/Home";
import { publicPath } from "common/routeConfig";

function Routes() {
  return (
    <Switch>
      <Route exact path={publicPath} component={Home} />
    </Switch>
  );
}

export default Routes;
